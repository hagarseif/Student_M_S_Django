from ast import Return
from urllib import request
from django.shortcuts import render

# Create your views here.

def home(request):
    return render(request, 'Student/home.html')

def personaldate(request):
    return render(request, 'Student/personaldata.html')

def Homework(request):
    return render(request, 'Student/Homework.html')  

def timeTable(request):
    return render(request, 'Student/timeTable.html')

def result(request):
    return render(request, 'Student/result.html')

def academicreport(request):
    return render(request,'Student/academicreport.html')  

def behavioralreport(request):
    return render(request,'Student/behavioralreport.html')  

def takeattendence(request):
    return render(request,'Student/takeattendence.html')  

def logout(request):
    return render(request,'Student/interface.html')    


     

